package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class ChecksumVerifier {

    public static String generateChecksum(String data) throws NoSuchAlgorithmException {
        // Create a MessageDigest instance for SHA-256
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        
        // Generate the hash (checksum) from the input data
        byte[] hash = messageDigest.digest(data.getBytes());
        
        // Convert the byte array into a readable hexadecimal format
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0'); // Append leading zero if needed
            hexString.append(hex);
        }
        
        return hexString.toString();
    }
    
    public static void main(String[] args) {
    	try {
    	String data = "August Moews Test";
    	
    	String checksum = generateChecksum(data);
    	
    	System.out.println("Generated Checksum: " + checksum);
    } catch (NoSuchAlgorithmException e) {
    	e.printStackTrace();
    	}
    }
}