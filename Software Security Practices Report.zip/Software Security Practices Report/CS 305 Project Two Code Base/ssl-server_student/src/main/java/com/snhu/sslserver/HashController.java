package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HashController {

    @GetMapping("/hash")
    public String getHash() {
        // This is the string you want to hash
        String data = "August Moews Test Data";

        // Generate the SHA-256 checksum (reuse your existing method)
        String checksum = "";
        try {
            checksum = ChecksumVerifier.generateChecksum(data);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Return the checksum
        return "Generated Checksum: " + checksum;
    }
}
